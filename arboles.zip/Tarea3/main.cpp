#include "BST.hpp"

int main(){
    BST<int> * arbol= new BST<int>();
    arbol->agregarNodo(8);
    arbol->agregarNodo(3);
    arbol->agregarNodo(1);
    arbol->agregarNodo(6);
    arbol->agregarNodo(4);
    arbol->agregarNodo(7);
    arbol->agregarNodo(10);
    arbol->agregarNodo(14);
    arbol->agregarNodo(13);

/*    arbol->imprimirPreOrder();
    arbol->imprimirInOrder();
    arbol->eliminarNodo(18);
    arbol->imprimirInOrder();
    arbol->eliminarNodo(13);
    arbol->imprimirInOrder();
    arbol->eliminarNodo(33);
    arbol->imprimirInOrder();*/
    arbol->imprimirAlturaABB();
    arbol->imprimirmostrarArbol();


    return 0;
}